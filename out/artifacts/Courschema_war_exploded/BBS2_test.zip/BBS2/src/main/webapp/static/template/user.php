    <div class="user_link">
        <img r="{headImg}" alt="更换头像" style="cursor:pointer" id="headImg">
        <k>{nikename}</k>
        <a class="close">×</a>
    </div>
    <ul class="U-act">
        <li><a class="btn" href="#add">New Post</a></li>
    </ul>
