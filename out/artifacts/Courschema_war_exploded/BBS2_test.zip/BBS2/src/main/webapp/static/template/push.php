<form method="post" id="A">
  <p class="A-tag o"></p>
  <input type="hidden" name="tag" class="h-tag">
  <p><input type="text" name="title" class="text" placeholder="title" required=""></p>
  <p><textarea name="message" class="text" rows="7" placeholder="Write something... \n\nyou can use Markdown \nor try to paste or drop a picture" required=""></textarea></p>
  <p><button type="button" class="btn">发表内容</button></p>
</form>