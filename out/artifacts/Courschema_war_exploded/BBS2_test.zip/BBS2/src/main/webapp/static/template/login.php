<form method="post" id="Ul">
        <p><input class="text" name="id" placeholder="输入昵称或邮箱" required=""></p>

        <p><input class="text" type="password" name="password" placeholder="请输入密码" pattern=".+"></p>

        <p>
            <button type="button" class="btn" id="loginBtn">登录 (ノ≧∇≦)ノ</button>
        </p>
    </form>
    <div class="U-act">
        <p>尚未注册？</p>
        <button type="button" class="btn Greg">加入我们 ٩͡[๏v͡๏]۶</button>
    </div>