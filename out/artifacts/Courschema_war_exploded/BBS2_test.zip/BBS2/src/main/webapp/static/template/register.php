<form method="post" id="Ur" autocomplete="off">
	<p><input class="text" name="nikename" placeholder="请输入昵称" required=""></p>
	<p><input class="text" name="email" placeholder="请输入邮箱" required=""></p>
	<p><input class="text" type="password" name="password" placeholder="请输入密码" pattern=".+"></p>
	<p><button type="button" class="btn" id="joinBtn">加入我们 ٩͡[๏v͡๏]۶ </button></p>
</form>
<div class="U-act">
	<p>已有账户？</p>
	<button type="button" class="btn Glogin">登录 (ノ≧∇≦)ノ </button>
</div>
