<form class="Cf" method="post"><p><textarea name="msg" id="Msg" placeholder="Reply something... \n\nyou can use Markdown \nor try to paste or drop a picture" rows="4" required=""></textarea></p>
    <p>
        <button type="button" class="btn" id="replyBtn">Reply</button>
    </p>
    <input type="hidden" name="aid" value="{aid}">
    <ul class="smile c">
        <li>ฅ(๑˙˙๑)ฅ</li>
        <li>(≥ω≤)</li>
        <li>(๑• ̀д•́ )✧</li>
        <li>(* ￣＾￣)</li>
        <li>(๑￫ܫ￩)</li>
        <li>(/・ω・＼)</li>
        <li>(　・ˍ・)</li>
        <li>（￣▽￣）</li>
        <li>(=・ω・=)</li>
        <li> (/ω＼)</li>
        <li>(〜￣△￣)〜</li>
        <li>(･∀･)</li>
        <li>(°∀°)ﾉ</li>
        <li>╮(￣▽￣)╭</li>
        <li>( ´_ゝ｀)</li>
        <li>("▔□▔)/</li>
        <li> (。・ω・)</li>
        <li>（/TДT)/</li>
        <li>(｡･ω･｡)</li>
        <li>(ノ≧∇≦)ノ</li>
        <li>(´･_･`)</li>
        <li>(-_-#)</li>
        <li>（￣へ￣）</li>
        <li>ヽ(`Д´)ﾉ</li>
        <li>(╯°口°)╯(┴—┴</li>
        <li>_(:3」∠)_</li>
        <li>٩͡[๏̯͡๏]۶</li>
        <li>٩(×̯×)۶</li>
        <li>´_ゝ｀</li>
    </ul>
</form>
