package com.honey.entity.extend;

/**
 * @description 网易云音乐
 * @author: chenPeng
 * @date: 2015/9/14 14:31
 * Copyright © 2015/9/14 Shanghai Raxtone Software Co.,Ltd Allright Reserved
 */
public class WyyVo {

    private String name;
    private String url;
    private String singer;
    private Integer id;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
