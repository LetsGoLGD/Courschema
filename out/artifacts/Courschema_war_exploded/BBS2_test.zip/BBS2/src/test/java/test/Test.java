package test;

/**
 * @description
 * @author: chenPeng
 * @date: 2015/9/9 9:23
 * Copyright © 2015/9/9 Shanghai Raxtone Software Co.,Ltd Allright Reserved
 */
public class Test {

//    public static void main(String[] args) throws IOException {
//        String markdownString = "```javascript\n console.log('hello''); \n \n var el = document.createElement('div') \n```";
//        String html = new Markdown4jProcessor().process(markdownString);
//        System.out.println(html);
//    }
}
